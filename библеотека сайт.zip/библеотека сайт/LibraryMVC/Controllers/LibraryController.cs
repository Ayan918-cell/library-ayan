using LibraryMVC.Data;
using LibraryMVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace LibraryMVC.Controllers
{
    public class LibraryController : Controller
    {
        private readonly AppDbContext _context;

        public LibraryController(AppDbContext context)
        {
            _context = context;
        }

        // Главная страница
        public IActionResult Index()
        {
            var books = _context.Books.ToList();
            return View(books);
        }

        // Добавление книги (GET)
        [HttpGet]
        public IActionResult AddBook() => View();

        // Добавление книги (POST)
        [HttpPost]
        public IActionResult AddBook(Book book)
        {
            if (ModelState.IsValid)
            {
                _context.Books.Add(book);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(book);
        }

        // Выдача книги
        public IActionResult Borrow(int id)
        {
            var book = _context.Books.Find(id);
            if (book != null && book.IsAvailable)
            {
                book.IsAvailable = false;
                _context.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        // Возврат книги
        public IActionResult Return(int id)
        {
            var book = _context.Books.Find(id);
            if (book != null && !book.IsAvailable)
            {
                book.IsAvailable = true;
                _context.SaveChanges();
            }
            return RedirectToAction("Index");
        }
    }
}